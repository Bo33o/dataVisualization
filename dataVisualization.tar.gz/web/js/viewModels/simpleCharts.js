/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your simpleCharts ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojselectcombobox', 'ojs/ojchart', 'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojselectcombobox'],
        function (oj, ko, $) {

            function SimpleChartsViewModel() {
                var self = this;

                self.chartType = ko.observable("bar");



                self.stackValue = ko.observable('off');
                self.orientationValue = ko.observable('vertical');

                self.header = [];
                self.headerCombo = [];
                self.series = [];
                self.splitedData = [];
                self.columns = [];

                self.barSeries = ko.observableArray([]);
                self.barGroups = ko.observableArray([]);


                self.hiddenCategories = ko.observableArray([]);

                self.inputData = 'prenom\\tMath\\tPhysics\\tProgramming\\tnom\\nbadr\\t2\\t3\\t4\\tezzir\\nwafae\\t8\\t7\\t6\\tabder';

                self.coordinateSystem = ko.observable('cartesian');

                self.selectedItems = [];
                
                self.groupDetection = ko.observable("automatic");
                
                self.selectedGroups = ko.observableArray([]);

                self.splitData = function (inputData) {
                    var rows = self.inputData.split(/\\n/);

                    self.splitedData = [];
                    self.series = [];
                    self.header = [];
                    self.headerCombo = [];

                    for (var i = 0; i < rows.length; i++) {
                        self.splitedData[i] = rows[i].split(/\\t/);

                        if (i > 0)
                            self.series.push({items: rows[i].split(/\\t/)});
                    }

                    if (self.splitedData.length > 0) {
                        self.header = self.splitedData[0];
                        
                        for (var i = 0; i < self.header.length; i++) {
                            self.headerCombo.push({id:i,label:self.header[i]})
                            
                        }
                    }
                }

                self.getColumnValues = function (matrix, n) {
                    return matrix.map(function (value, index) {
                        return value[n];
                    });
                }

                self.getGroups = function () {
                    var customGroupsIndexs = [];
                    var grp = [];
                    var seriesNames = [];
                    var headerLgth = self.header.length;
                    self.cols = [];
                    var matrix = self.splitedData;

                    for (var i = 0; i < headerLgth; i++) {
                        self.columns[i] = self.getColumnValues(matrix, i);
                        self.cols[i] = [...self.columns[i]];
                        self.cols[i].shift();
                        if (self.cols[i].some(isNaN)) {
                            seriesNames.push(i);
                        }
                    }

                    var headerAfter = [];//self.columns[0];
                    self.series = [];
                    self.groups = [];

                    for (var i = 0; i < self.columns.length; i++) {
                        var serieLabel = "";
                        var serieItem = [];
                        for (var j = 0; j < self.columns[i].length; j++) {

                            if (isNumber(self.columns[i][j])) {
                                serieItem.push(self.columns[i][j]);
                            } else {
                                if (j == 0) {
                                    serieLabel += self.columns[i][j] + " ";
                                }

                                if (j > 0) {
                                    if (headerAfter[j - 1]) {
                                        headerAfter[j - 1] += " " + self.columns[i][j];
                                    } else {
                                        headerAfter[j - 1] = self.columns[i][j];
                                    }
                                }

                            }
                        }
                        self.series.push({name: serieLabel, items: serieItem});
                    }

                    self.barSeries(self.series);
                    self.barGroups(headerAfter);
                }


                self.parseData = function (event) {


                    self.splitData(self.inputData);

//                    self.barSeries(self.series);
//                    self.barGroups(self.header);


                    self.getGroups();

                };

                self.parseData();


                self.selectionListener = function (event) {
                    
                }

                //check if variable is numeric
                function isNumber(n) {
                    return !isNaN(parseFloat(n)) && isFinite(n);
                }





                self.handleActivated = function (info) {
                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after the View is inserted into the
                 * document DOM.  The application can put logic that requires the DOM being
                 * attached here.
                 * @param {Object} info - An object with the following key-value pairs:
                 * @param {Node} info.element - DOM element or where the binding is attached. This may be a 'virtual' element (comment node).
                 * @param {Function} info.valueAccessor - The binding's value accessor.
                 * @param {boolean} info.fromCache - A boolean indicating whether the module was retrieved from cache.
                 */
                self.handleAttached = function (info) {
                    // Implement if needed
                };


                /**
                 * Optional ViewModel method invoked after the bindings are applied on this View. 
                 * If the current View is retrieved from cache, the bindings will not be re-applied
                 * and this callback will not be invoked.
                 * @param {Object} info - An object with the following key-value pairs:
                 * @param {Node} info.element - DOM element or where the binding is attached. This may be a 'virtual' element (comment node).
                 * @param {Function} info.valueAccessor - The binding's value accessor.
                 */
                self.handleBindingsApplied = function (info) {
                    // Implement if needed
                };

                /*
                 * Optional ViewModel method invoked after the View is removed from the
                 * document DOM.
                 * @param {Object} info - An object with the following key-value pairs:
                 * @param {Node} info.element - DOM element or where the binding is attached. This may be a 'virtual' element (comment node).
                 * @param {Function} info.valueAccessor - The binding's value accessor.
                 * @param {Array} info.cachedNodes - An Array containing cached nodes for the View if the cache is enabled.
                 */
                self.handleDetached = function (info) {
                    // Implement if needed
                };
            }

            /*
             * Returns a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.  Return an instance of the ViewModel if
             * only one instance of the ViewModel is needed.
             */
            return new SimpleChartsViewModel();
        }
);
